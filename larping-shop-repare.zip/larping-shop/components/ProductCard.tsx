import Link from "next/link";

export type PublicProduct = {
  id: string;
  name: string;
  slug: string;
  price: number;
  stock: number;
  badge: string | null;
  images: string;
  category: { name: string; slug: string } | null;
};

function firstImage(images: string): string | null {
  try {
    const parsed = JSON.parse(images);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed[0] : null;
  } catch {
    return null;
  }
}

export function ProductCard({ product }: { product: PublicProduct }) {
  const img = firstImage(product.images);

  return (
    <Link
      href={`/produit/${product.slug}`}
      className="group rounded-xl border border-white/10 bg-surface p-4 hover:border-gold/30 transition-colors"
    >
      <div className="relative aspect-square rounded-lg bg-surfaceHigh mb-3 overflow-hidden">
        {img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={img}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform"
          />
        ) : (
          <div className="w-full h-full grid place-items-center text-mist text-xs">
            Pas d&apos;image
          </div>
        )}
        {product.badge && (
          <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-gold text-ink text-[11px] font-medium">
            {product.badge}
          </span>
        )}
        {product.stock === 0 && (
          <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-crimson/90 text-parchment text-[11px] font-medium">
            Épuisé
          </span>
        )}
      </div>
      {product.category && (
        <p className="text-[11px] uppercase tracking-wide text-mist mb-1">{product.category.name}</p>
      )}
      <p className="text-sm text-parchment truncate">{product.name}</p>
      <p className="text-sm text-gold mt-1">{(product.price / 100).toFixed(2)} €</p>
    </Link>
  );
}
