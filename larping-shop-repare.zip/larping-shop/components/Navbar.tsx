"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import {
  Search,
  Heart,
  ShoppingCart,
  Bell,
  User,
  Shield,
  Menu,
  X,
  Swords,
} from "lucide-react";

const CENTER_LINKS = [
  { href: "/", label: "Accueil" },
  { href: "/boutique", label: "Boutique" },
  { href: "/categories", label: "Catégories" },
  { href: "/nouveautes", label: "Nouveautés" },
  { href: "/meilleures-ventes", label: "Meilleures ventes" },
  { href: "/a-propos", label: "À propos" },
  { href: "/support", label: "Support" },
];

export function Navbar() {
  const { data: session } = useSession();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [cartCount] = useState(0); // à brancher sur le vrai store panier

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isStaff = session?.user?.role === "ADMIN" || session?.user?.role === "FONDA";

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-ink/80 backdrop-blur-md border-b border-white/10 shadow-glow"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link
            href="/"
            className="group flex items-center gap-2 shrink-0 focus-ring rounded-md"
          >
            <span className="grid place-items-center h-9 w-9 rounded-full border border-gold/40 bg-surface transition-transform duration-300 group-hover:rotate-[12deg] group-hover:border-gold">
              <Swords className="h-4 w-4 text-gold" />
            </span>
            <span className="font-display text-lg tracking-tight text-parchment group-hover:text-goldSoft transition-colors">
              Larping Shop
            </span>
          </Link>

          {/* Liens centraux (desktop) */}
          <nav className="hidden lg:flex items-center gap-1">
            {CENTER_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-3 py-2 text-sm text-mist hover:text-parchment rounded-md hover:bg-white/5 transition-colors focus-ring"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Recherche (desktop) */}
          <div className="hidden md:flex items-center flex-1 max-w-xs">
            <div className="flex items-center gap-2 w-full rounded-full border border-white/10 bg-surface px-3 py-1.5 focus-within:border-gold/60 transition-colors">
              <Search className="h-4 w-4 text-mist shrink-0" />
              <input
                type="search"
                placeholder="Rechercher un produit..."
                className="bg-transparent outline-none text-sm placeholder:text-mist w-full text-parchment"
              />
            </div>
          </div>

          {/* Icônes à droite (desktop) */}
          <div className="hidden md:flex items-center gap-1">
            <IconButton href="/boutique" label="Recherche" className="md:hidden">
              <Search className="h-5 w-5" />
            </IconButton>
            <IconButton href="/favoris" label="Favoris">
              <Heart className="h-5 w-5" />
            </IconButton>
            <IconButton href="/panier" label="Panier">
              <span className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 grid place-items-center h-4 w-4 rounded-full bg-crimson text-[10px] font-semibold text-parchment animate-[pulse_1.6s_ease-in-out_infinite]">
                    {cartCount}
                  </span>
                )}
              </span>
            </IconButton>
            <IconButton href="/notifications" label="Notifications">
              <Bell className="h-5 w-5" />
            </IconButton>

            {isStaff && (
              <Link
                href="/admin"
                className="ml-1 flex items-center gap-1.5 rounded-full border border-gold/40 px-3 py-1.5 text-sm text-goldSoft hover:bg-gold/10 hover:border-gold transition-colors focus-ring"
              >
                <Shield className="h-4 w-4" />
                Administration
              </Link>
            )}

            {!session ? (
              <div className="flex items-center gap-2 ml-2">
                <Link
                  href="/login"
                  className="px-3 py-1.5 text-sm text-parchment hover:text-goldSoft transition-colors focus-ring rounded-md"
                >
                  Connexion
                </Link>
                <Link
                  href="/register"
                  className="px-3 py-1.5 text-sm rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors focus-ring"
                >
                  Créer un compte
                </Link>
              </div>
            ) : (
              <div className="relative ml-2">
                <button
                  onClick={() => setUserMenuOpen((v) => !v)}
                  className="flex items-center gap-2 rounded-full border border-white/10 pl-1 pr-3 py-1 hover:border-white/30 transition-colors focus-ring"
                >
                  <span className="grid place-items-center h-7 w-7 rounded-full bg-surfaceHigh">
                    <User className="h-4 w-4 text-mist" />
                  </span>
                  <span className="text-sm text-parchment">{session.user?.name}</span>
                </button>
                {userMenuOpen && (
                  <div
                    onMouseLeave={() => setUserMenuOpen(false)}
                    className="absolute right-0 mt-2 w-52 rounded-xl border border-white/10 bg-surface shadow-glow overflow-hidden animate-[fadeIn_0.15s_ease-out]"
                  >
                    <UserMenuLink href="/compte">Mon compte</UserMenuLink>
                    <UserMenuLink href="/compte/commandes">Mes commandes</UserMenuLink>
                    <UserMenuLink href="/favoris">Mes favoris</UserMenuLink>
                    <UserMenuLink href="/compte/parametres">Paramètres</UserMenuLink>
                    <button
                      onClick={() => signOut()}
                      className="w-full text-left px-4 py-2.5 text-sm text-crimson hover:bg-white/5 transition-colors"
                    >
                      Déconnexion
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Bouton menu mobile */}
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden p-2 rounded-md hover:bg-white/5 focus-ring"
            aria-label="Ouvrir le menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Menu mobile */}
      <div
        className={`md:hidden overflow-hidden transition-[max-height,opacity] duration-300 ease-out border-b border-white/10 bg-ink/95 backdrop-blur-md ${
          mobileOpen ? "max-h-[32rem] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <div className="px-4 py-4 space-y-1">
          <div className="flex items-center gap-2 rounded-full border border-white/10 bg-surface px-3 py-2 mb-3">
            <Search className="h-4 w-4 text-mist" />
            <input
              type="search"
              placeholder="Rechercher un produit..."
              className="bg-transparent outline-none text-sm placeholder:text-mist w-full text-parchment"
            />
          </div>
          {CENTER_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="block px-3 py-2.5 rounded-md text-parchment hover:bg-white/5"
            >
              {link.label}
            </Link>
          ))}
          <Link href="/favoris" className="block px-3 py-2.5 rounded-md text-parchment hover:bg-white/5">
            Favoris
          </Link>
          <Link href="/panier" className="block px-3 py-2.5 rounded-md text-parchment hover:bg-white/5">
            Panier
          </Link>
          {isStaff && (
            <Link
              href="/admin"
              className="block px-3 py-2.5 rounded-md text-goldSoft hover:bg-gold/10"
            >
              ⚙️ Administration
            </Link>
          )}
          <div className="pt-2 border-t border-white/10 mt-2">
            {!session ? (
              <div className="flex gap-2 pt-2">
                <Link href="/login" className="flex-1 text-center px-3 py-2 rounded-md border border-white/10">
                  Connexion
                </Link>
                <Link href="/register" className="flex-1 text-center px-3 py-2 rounded-md bg-gold text-ink font-medium">
                  Créer un compte
                </Link>
              </div>
            ) : (
              <button onClick={() => signOut()} className="w-full text-left px-3 py-2.5 text-crimson">
                Déconnexion
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

function IconButton({
  href,
  label,
  children,
  className = "",
}: {
  href: string;
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      href={href}
      aria-label={label}
      className={`p-2 rounded-full text-mist hover:text-parchment hover:bg-white/5 transition-colors focus-ring ${className}`}
    >
      {children}
    </Link>
  );
}

function UserMenuLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="block px-4 py-2.5 text-sm text-parchment hover:bg-white/5 transition-colors">
      {children}
    </Link>
  );
}
