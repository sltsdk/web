import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const isAdminArea = req.nextUrl.pathname.startsWith("/admin");
    const isAdminLoginPage = req.nextUrl.pathname === "/admin/login";

    if (isAdminArea && !isAdminLoginPage) {
      const role = token?.role;
      if (role !== "ADMIN" && role !== "FONDA") {
        return NextResponse.redirect(new URL("/admin/login", req.url));
      }
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      // On laisse passer /admin/login sans session pour permettre la connexion staff.
      authorized: ({ req, token }) => {
        if (req.nextUrl.pathname === "/admin/login") return true;
        return Boolean(token);
      },
    },
  }
);

export const config = {
  matcher: ["/admin/:path*"],
};
