import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { hasPermission, PermissionKey } from "@/lib/permissions";

/**
 * Retourne la session si l'utilisateur est staff (ADMIN/FONDA) ET a la
 * permission demandée (FONDA a toujours tout). Retourne null sinon.
 * À utiliser dans CHAQUE route admin — c'est la seule vérification qui compte,
 * l'affichage ou non d'un bouton côté frontend n'a aucune valeur de sécurité.
 */
export async function requireStaff(permissionKey: PermissionKey) {
  const session = await getServerSession(authOptions);
  if (!session) return null;
  if (session.user.role !== "ADMIN" && session.user.role !== "FONDA") return null;
  const allowed = await hasPermission(session.user.id, permissionKey);
  if (!allowed) return null;
  return session;
}

export async function requireFondaSession() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "FONDA") return null;
  return session;
}
