/**
 * Rate limiting anti-brute-force pour la connexion.
 *
 * ⚠️ Implémentation en mémoire : suffisante pour un seul serveur / dev.
 * En production avec plusieurs instances, remplacer ce module par un
 * store partagé (Redis, Upstash...) en gardant la même interface.
 */

type Attempt = { count: number; firstAttempt: number; lockedUntil?: number };

const attempts = new Map<string, Attempt>();

const MAX_ATTEMPTS = Number(process.env.LOGIN_MAX_ATTEMPTS ?? 5);
const LOCK_MINUTES = Number(process.env.LOGIN_LOCK_MINUTES ?? 15);
const WINDOW_MS = 15 * 60 * 1000;

export function checkRateLimit(key: string): { allowed: boolean; retryAfterSeconds?: number } {
  const now = Date.now();
  const entry = attempts.get(key);

  if (entry?.lockedUntil && entry.lockedUntil > now) {
    return { allowed: false, retryAfterSeconds: Math.ceil((entry.lockedUntil - now) / 1000) };
  }

  if (!entry || now - entry.firstAttempt > WINDOW_MS) {
    attempts.set(key, { count: 0, firstAttempt: now });
  }

  return { allowed: true };
}

export function recordFailedAttempt(key: string) {
  const now = Date.now();
  const entry = attempts.get(key) ?? { count: 0, firstAttempt: now };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = now + LOCK_MINUTES * 60 * 1000;
  }
  attempts.set(key, entry);
}

export function resetAttempts(key: string) {
  attempts.delete(key);
}
