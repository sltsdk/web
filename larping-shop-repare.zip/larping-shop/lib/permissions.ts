import { prisma } from "./prisma";
import type { Role } from "@prisma/client";

export const PERMISSION_KEYS = [
  "products",
  "stocks",
  "prices",
  "categories",
  "reviews",
  "proofs",
  "orders",
  "users",
  "tickets",
  "settings",
] as const;

export type PermissionKey = (typeof PERMISSION_KEYS)[number];

/**
 * Vérifie qu'un utilisateur a le droit d'effectuer une action.
 * - FONDA : accès total, toujours.
 * - ADMIN : dépend de sa ligne Permission en base.
 * - USER : jamais.
 *
 * Cette fonction doit être appelée dans CHAQUE route API sensible.
 * Ne jamais se fier à ce que le frontend cache un bouton : ça n'empêche rien
 * côté serveur si la route elle-même ne revérifie pas.
 */
export async function hasPermission(userId: string, key: PermissionKey): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { permission: true },
  });
  if (!user || !user.isActive) return false;
  if (user.role === "FONDA") return true;
  if (user.role !== "ADMIN") return false;
  return Boolean(user.permission?.[key]);
}

export function isStaffRole(role: Role) {
  return role === "ADMIN" || role === "FONDA";
}

/**
 * Règle de sécurité configurable pour la gestion des FONDA entre eux :
 * un FONDA ne peut jamais se rétrograder/désactiver lui-même, et ne peut
 * agir sur un autre FONDA que si REQUIRE_MULTI_FONDA_CONFIRM n'est pas
 * strictement bloquant (ici : on exige simplement qu'il reste toujours au
 * moins un FONDA actif dans le système).
 */
export async function canModifyFonda(actingUserId: string, targetUserId: string) {
  if (actingUserId === targetUserId) {
    return { ok: false, reason: "Un FONDA ne peut pas modifier son propre rôle critique." };
  }
  const activeFondaCount = await prisma.user.count({ where: { role: "FONDA", isActive: true } });
  if (activeFondaCount <= 1) {
    return { ok: false, reason: "Impossible : il doit toujours rester au moins un FONDA actif." };
  }
  return { ok: true as const };
}
