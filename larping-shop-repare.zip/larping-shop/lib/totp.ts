import { authenticator } from "otplib";
import QRCode from "qrcode";

export function generateTotpSecret() {
  return authenticator.generateSecret();
}

export function verifyTotpCode(secret: string, code: string) {
  try {
    return authenticator.verify({ token: code, secret });
  } catch {
    return false;
  }
}

export async function totpQrCodeDataUrl(username: string, secret: string, shopName: string) {
  const otpauth = authenticator.keyuri(username, shopName, secret);
  return QRCode.toDataURL(otpauth);
}
