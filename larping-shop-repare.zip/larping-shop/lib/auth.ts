import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { checkRateLimit, recordFailedAttempt, resetAttempts } from "./rateLimit";
import { verifyTotpCode } from "./totp";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 }, // 8h, configurable
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      id: "credentials",
      name: "Identifiants",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Mot de passe", type: "password" },
        totpCode: { label: "Code 2FA", type: "text" },
      },
      async authorize(credentials, req) {
        const email = credentials?.email?.trim().toLowerCase();
        const password = credentials?.password ?? "";
        const totpCode = credentials?.totpCode?.trim();
        // x-forwarded-for peut contenir plusieurs IP séparées par des virgules
        // (client, proxy1, proxy2...) : seule la première nous intéresse, et
        // seulement si on est bien derrière un reverse proxy de confiance qui
        // écrase ce header plutôt que de le faire suivre tel quel depuis le
        // client. Sur un déploiement sans proxy de confiance, ce header est
        // arbitrairement falsifiable par l'appelant et ne doit pas servir de
        // clé de rate limiting fiable à lui seul.
        const forwardedFor = (req?.headers as Record<string, string> | undefined)?.[
          "x-forwarded-for"
        ];
        const ip = forwardedFor?.split(",")[0]?.trim() || "unknown";

        if (!email || !password) return null;

        const rateLimitKey = `${email}:${ip}`;
        const rl = checkRateLimit(rateLimitKey);
        if (!rl.allowed) {
          throw new Error(
            `Trop de tentatives. Réessaie dans ${rl.retryAfterSeconds ?? 60} secondes.`
          );
        }

        const user = await prisma.user.findUnique({ where: { email } });

        const fail = async (reason: string) => {
          recordFailedAttempt(rateLimitKey);
          await prisma.loginLog.create({
            data: { userId: user?.id, email, success: false, ip: String(ip) },
          });
          throw new Error(reason);
        };

        if (!user || !user.isActive) return await fail("Identifiants invalides.");

        const validPassword = await bcrypt.compare(password, user.passwordHash);
        if (!validPassword) return await fail("Identifiants invalides.");

        // 2FA : si déjà activée, elle est obligatoire pour terminer la connexion.
        if (user.totpEnabled) {
          if (!totpCode) throw new Error("TOTP_REQUIRED");
          const validTotp = verifyTotpCode(user.totpSecret ?? "", totpCode);
          if (!validTotp) return await fail("Code 2FA invalide.");
        }
        // Si un FONDA n'a pas encore activé le 2FA, on le laisse se connecter
        // mais son accès au dashboard sera bloqué (cf middleware) tant qu'il
        // n'a pas configuré son application d'authentification sur
        // /admin/securite/2fa. Cela évite le problème de "poule et l'œuf"
        // (impossible de configurer une 2FA sans être connecté).

        resetAttempts(rateLimitKey);
        await prisma.loginLog.create({
          data: { userId: user.id, email, success: true, ip: String(ip) },
        });

        return {
          id: user.id,
          name: user.username,
          email: user.email,
          role: user.role,
          totpEnabled: user.totpEnabled,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as unknown as { role: "USER" | "ADMIN" | "FONDA" }).role;
        token.id = (user as { id: string }).id;
        token.totpEnabled = (user as { totpEnabled?: boolean }).totpEnabled ?? false;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as { id?: string; role?: string; totpEnabled?: boolean }).id = token.id as string;
        (session.user as { id?: string; role?: string; totpEnabled?: boolean }).role = token.role as string;
        (session.user as { id?: string; role?: string; totpEnabled?: boolean }).totpEnabled =
          token.totpEnabled as boolean;
      }
      return session;
    },
  },
};
