# Larping Shop

Boutique e-commerce Next.js 14 (App Router) + TypeScript + Prisma + NextAuth,
avec un vrai système de rôles `USER → ADMIN → FONDA` vérifié **côté serveur**.

## Ce qui est réellement fonctionnel

- Inscription / connexion / déconnexion, mots de passe **hashés en bcrypt** (jamais en clair).
- Rôles `USER`, `ADMIN`, `FONDA` stockés en base, avec permissions granulaires par ADMIN
  (`Permission` en base, vérifiées dans chaque route API via `hasPermission()`).
- `/admin/login` : authentification staff séparée de la connexion utilisateur normale.
- Rate limiting anti-brute-force sur la connexion + journal des connexions (`LoginLog`).
- 2FA (TOTP, type Google Authenticator) **obligatoire pour FONDA**, avec QR code et
  flux de configuration forcé avant tout accès au dashboard.
- Journal des actions administrateur (`AdminLog`) sur les opérations sensibles.
- Gestion du Staff (page FONDA) : création d'ADMIN, matrice de permissions, activation/
  désactivation, avec confirmation supplémentaire obligatoire pour les actions critiques
  sur un autre FONDA, et une règle serveur empêchant de désactiver le dernier FONDA actif.
- Aucun secret FONDA en dur : le premier compte FONDA est créé par un script serveur
  (`prisma/seed.ts`) lisant des variables d'environnement, jamais commit dans le code.
- Navbar complète (logo animé, liens, recherche, favoris/panier/notifications/profil,
  bouton Administration conditionnel, menu mobile, sticky + flou au scroll).
- Schéma de données complet pour produits, catégories, avis, preuves, commandes,
  favoris, tickets, codes promo, paramètres du shop.

## Ce qui est livré en base solide mais pas encore en interface complète

Pour rester honnête sur le périmètre : les pages `/admin/produits`, `/commandes`,
`/avis`, `/preuves`, `/tickets`, `/utilisateurs`, `/logs` sont des **stubs connectés
à la vraie base de données**, pas de fausses maquettes. Il leur manque le CRUD complet
côté UI (formulaires, filtres, tri, upload d'images). Le modèle Prisma et le pattern de
sécurité (`getServerSession` + `hasPermission`) sont déjà en place : ajouter ces routes
suit exactement le même schéma que `/api/admin/products`. Idem pour la boutique publique
(recherche instantanée, filtres, produits similaires) : le hero et la home sont réels,
le reste des pages catalogue est à construire sur le même modèle que `app/page.tsx`.

## 1. Installer les dépendances

```bash
npm install
```

## 2. Configurer la base de données

Le projet utilise SQLite par défaut (aucun serveur à installer, fichier local).
Pour passer en PostgreSQL en production, changer `provider = "postgresql"` dans
`prisma/schema.prisma` et adapter `DATABASE_URL`.

```bash
cp .env.example .env
npx prisma db push
```

## 3. Configurer le `.env`

Ouvrir `.env` et renseigner :

- `NEXTAUTH_SECRET` : générer avec `openssl rand -base64 32`
- `FONDA_USERNAME`, `FONDA_EMAIL`, `FONDA_PASSWORD` : identifiants du tout premier
  compte propriétaire (utilisés uniquement par le script de seed, à retirer ensuite).

Ne jamais committer ce fichier `.env` (déjà exclu par `.gitignore`).

## 4. Créer le premier compte FONDA

```bash
npm run db:seed
```

Ce script lit les variables `FONDA_*` du `.env`, hash le mot de passe, et crée le
compte propriétaire directement en base. Aucun mot de passe FONDA n'apparaît jamais
dans le code source ou le frontend.

## 5. Lancer le site

```bash
npm run dev
```

Le site est accessible sur `http://localhost:3000`.

## 6. Accéder au dashboard

1. Aller sur `http://localhost:3000/admin/login`
2. Se connecter avec l'email/mot de passe FONDA défini à l'étape 3
3. Lors de la première connexion, tu es automatiquement redirigé vers
   `/admin/securite/2fa` : scanner le QR code avec une app d'authentification
   (Google Authenticator, Authy, etc.) et entrer le code généré pour activer le 2FA
   (obligatoire pour FONDA — le dashboard reste bloqué tant qu'il n'est pas activé).
4. Une fois le 2FA activé, tu arrives sur `/admin`.

## 7. Créer ton premier compte ADMIN

1. Dans le dashboard, aller dans **Gestion du staff** (`/admin/staff`)
2. Cliquer sur **+ Créer un administrateur**
3. Renseigner nom d'utilisateur, email, mot de passe temporaire, et cocher les
   permissions à accorder (produits, commandes, avis, preuves, utilisateurs...)
4. L'admin créé peut ensuite se connecter sur `/admin/login` avec ces identifiants.
   Ses permissions sont vérifiées côté serveur sur chaque route, pas seulement
   cachées dans l'interface.
