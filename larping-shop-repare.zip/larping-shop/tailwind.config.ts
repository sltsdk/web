import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0F0D12",
        surface: "#1B1720",
        surfaceHigh: "#241F2B",
        parchment: "#EDE6D6",
        gold: "#C89B3C",
        goldSoft: "#E4C878",
        crimson: "#8B2635",
        mist: "#A7A0AE",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px rgba(200, 155, 60, 0.15)",
      },
    },
  },
  plugins: [],
};
export default config;
