import { prisma } from "@/lib/prisma";
import { ProductCard, type PublicProduct } from "@/components/ProductCard";

export default async function NouveautesPage() {
  const products = await prisma.product.findMany({
    take: 24,
    orderBy: { createdAt: "desc" },
    include: { category: { select: { name: true, slug: true } } },
  });

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <h1 className="font-display text-3xl text-parchment mb-8">Nouveautés</h1>

      {products.length === 0 ? (
        <p className="text-mist">Aucun produit pour l&apos;instant.</p>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {products.map((p: PublicProduct) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
