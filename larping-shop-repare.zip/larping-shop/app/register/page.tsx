"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Une erreur est survenue.");
      return;
    }
    router.push("/login");
  }

  return (
    <div className="mx-auto max-w-sm px-6 py-20">
      <h1 className="font-display text-3xl text-parchment mb-2">Créer un compte</h1>
      <p className="text-mist text-sm mb-8">Rejoins la communauté Larping Shop.</p>

      <form onSubmit={onSubmit} className="space-y-4">
        <Field label="Nom d'utilisateur" value={form.username} onChange={(v) => setForm({ ...form, username: v })} />
        <Field label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
        <Field
          label="Mot de passe (8 caractères min.)"
          type="password"
          value={form.password}
          onChange={(v) => setForm({ ...form, password: v })}
        />
        {error && <p className="text-sm text-crimson">{error}</p>}
        <button
          disabled={loading}
          className="w-full py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors disabled:opacity-60"
        >
          {loading ? "Création..." : "Créer mon compte"}
        </button>
      </form>

      <p className="mt-6 text-sm text-mist">
        Déjà un compte ?{" "}
        <Link href="/login" className="text-gold hover:text-goldSoft">
          Se connecter
        </Link>
      </p>
    </div>
  );
}

function Field({
  label,
  type = "text",
  value,
  onChange,
}: {
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="block text-sm text-mist mb-1.5">{label}</span>
      <input
        required
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/10 bg-surface px-3 py-2.5 text-parchment outline-none focus:border-gold/60 transition-colors"
      />
    </label>
  );
}
