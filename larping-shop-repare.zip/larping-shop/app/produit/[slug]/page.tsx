import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";

function firstImage(images: string): string | null {
  try {
    const parsed = JSON.parse(images);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed[0] : null;
  } catch {
    return null;
  }
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug },
    include: {
      category: true,
      reviews: {
        where: { published: true },
        include: { user: { select: { username: true } } },
        orderBy: { createdAt: "desc" },
      },
      proofs: {
        include: { author: { select: { username: true } } },
        orderBy: { createdAt: "desc" },
      },
    },
  });

  if (!product) notFound();

  const img = firstImage(product.images);
  const avgRating =
    product.reviews.length > 0
      ? product.reviews.reduce((sum: number, r: (typeof product.reviews)[number]) => sum + r.rating, 0) /
        product.reviews.length
      : null;

  return (
    <div className="mx-auto max-w-5xl px-6 py-12">
      <div className="grid md:grid-cols-2 gap-10">
        <div className="aspect-square rounded-2xl border border-white/10 bg-surface overflow-hidden">
          {img ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={img} alt={product.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full grid place-items-center text-mist">Pas d&apos;image</div>
          )}
        </div>

        <div>
          {product.category && (
            <p className="text-xs uppercase tracking-wide text-mist mb-2">{product.category.name}</p>
          )}
          <h1 className="font-display text-3xl text-parchment">{product.name}</h1>

          {avgRating !== null && (
            <p className="text-sm text-gold mt-2">
              {"★".repeat(Math.round(avgRating))}
              {"☆".repeat(5 - Math.round(avgRating))}{" "}
              <span className="text-mist">({product.reviews.length} avis)</span>
            </p>
          )}

          <p className="text-2xl text-gold mt-4">{(product.price / 100).toFixed(2)} €</p>
          <p className="text-sm text-mist mt-1">
            {product.stock > 0 ? `${product.stock} en stock` : "Rupture de stock"}
          </p>

          <p className="text-parchment/90 mt-6 whitespace-pre-line">{product.description}</p>

          {product.badge && (
            <span className="inline-block mt-4 px-3 py-1 rounded-full bg-gold/15 border border-gold/30 text-gold text-xs">
              {product.badge}
            </span>
          )}

          <button
            disabled={product.stock === 0}
            className="mt-8 w-full py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {product.stock === 0 ? "Indisponible" : "Ajouter au panier"}
          </button>
        </div>
      </div>

      {product.proofs.length > 0 && (
        <section className="mt-16">
          <h2 className="font-display text-xl text-parchment mb-4">Preuves</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {product.proofs.map((proof: (typeof product.proofs)[number]) => (
              <div key={proof.id} className="rounded-lg border border-white/10 bg-surface p-4">
                {proof.type === "image" ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={proof.content} alt="" className="rounded-md mb-2 max-h-48 object-cover" />
                ) : proof.type === "document" ? (
                  <a href={proof.content} className="text-gold text-sm underline" target="_blank">
                    Voir le document
                  </a>
                ) : (
                  <p className="text-sm text-parchment/90">{proof.content}</p>
                )}
                <p className="text-xs text-mist mt-2">par {proof.author.username}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="mt-16">
        <h2 className="font-display text-xl text-parchment mb-4">Avis</h2>
        {product.reviews.length === 0 ? (
          <p className="text-mist">Aucun avis pour l&apos;instant.</p>
        ) : (
          <div className="space-y-3">
            {product.reviews.map((r: (typeof product.reviews)[number]) => (
              <div key={r.id} className="rounded-lg border border-white/10 bg-surface p-4">
                <p className="text-gold text-sm">
                  {"★".repeat(r.rating)}
                  {"☆".repeat(5 - r.rating)}
                  {r.verified && <span className="text-xs text-mist ml-2">Achat vérifié</span>}
                </p>
                <p className="text-sm text-parchment/90 mt-1">{r.comment}</p>
                <p className="text-xs text-mist mt-1">par {r.user.username}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
