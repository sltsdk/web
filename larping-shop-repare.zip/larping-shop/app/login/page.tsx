"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError(res.error === "CredentialsSignin" ? "Identifiants invalides." : res.error);
      return;
    }
    router.push("/");
  }

  return (
    <div className="mx-auto max-w-sm px-6 py-20">
      <h1 className="font-display text-3xl text-parchment mb-2">Connexion</h1>
      <p className="text-mist text-sm mb-8">Accède à ton compte Larping Shop.</p>

      <form onSubmit={onSubmit} className="space-y-4">
        <Field label="Email" type="email" value={email} onChange={setEmail} />
        <Field label="Mot de passe" type="password" value={password} onChange={setPassword} />
        {error && <p className="text-sm text-crimson">{error}</p>}
        <button
          disabled={loading}
          className="w-full py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors disabled:opacity-60"
        >
          {loading ? "Connexion..." : "Se connecter"}
        </button>
      </form>

      <div className="mt-6 flex justify-between text-sm">
        <Link href="/mot-de-passe-oublie" className="text-mist hover:text-parchment">
          Mot de passe oublié ?
        </Link>
        <Link href="/register" className="text-gold hover:text-goldSoft">
          Créer un compte
        </Link>
      </div>

      <p className="mt-8 text-xs text-mist">
        Membre du staff ?{" "}
        <Link href="/admin/login" className="text-gold hover:text-goldSoft">
          Connexion administration
        </Link>
      </p>
    </div>
  );
}

function Field({
  label,
  type,
  value,
  onChange,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="block text-sm text-mist mb-1.5">{label}</span>
      <input
        required
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/10 bg-surface px-3 py-2.5 text-parchment outline-none focus:border-gold/60 transition-colors"
      />
    </label>
  );
}
