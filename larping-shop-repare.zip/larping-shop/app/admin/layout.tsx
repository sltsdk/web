import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const NAV_ITEMS: { href: string; label: string; key: string | null }[] = [
  { href: "/admin", label: "Statistiques", key: null },
  { href: "/admin/produits", label: "Produits", key: "products" },
  { href: "/admin/commandes", label: "Commandes", key: "orders" },
  { href: "/admin/avis", label: "Avis", key: "reviews" },
  { href: "/admin/preuves", label: "Preuves", key: "proofs" },
  { href: "/admin/tickets", label: "Tickets", key: "tickets" },
  { href: "/admin/utilisateurs", label: "Utilisateurs", key: "users" },
  { href: "/admin/logs", label: "Logs", key: null }, // FONDA uniquement, filtré plus bas
  { href: "/admin/staff", label: "Gestion du staff", key: null }, // FONDA uniquement
  { href: "/admin/parametres", label: "⚙️ Configuration du Shop", key: null }, // FONDA uniquement
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  // Défense en profondeur : le middleware filtre déjà, on revérifie ici.
  if (!session || (session.user.role !== "ADMIN" && session.user.role !== "FONDA")) {
    redirect("/admin/login");
  }

  // Un FONDA doit avoir activé le 2FA avant d'accéder à quoi que ce soit d'autre.
  if (session.user.role === "FONDA" && !session.user.totpEnabled) {
    redirect("/admin/securite/2fa");
  }

  const isFonda = session.user.role === "FONDA";
  const permission = isFonda
    ? null
    : await prisma.permission.findUnique({ where: { userId: session.user.id } });

  const visibleItems = NAV_ITEMS.filter((item) => {
    if (item.href === "/admin/logs" || item.href === "/admin/staff" || item.href === "/admin/parametres") {
      return isFonda;
    }
    if (!item.key) return true;
    return isFonda || Boolean(permission?.[item.key as keyof typeof permission]);
  });

  return (
    <div className="mx-auto max-w-7xl px-6 py-8 grid lg:grid-cols-[220px_1fr] gap-8">
      <aside className="space-y-1">
        <p className="text-xs uppercase tracking-wide text-mist mb-3 px-2">
          {session.user.role === "FONDA" ? "Fonda" : "Administration"}
        </p>
        {visibleItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="block px-3 py-2 rounded-md text-sm text-parchment hover:bg-white/5 transition-colors"
          >
            {item.label}
          </Link>
        ))}
      </aside>
      <div>{children}</div>
    </div>
  );
}
