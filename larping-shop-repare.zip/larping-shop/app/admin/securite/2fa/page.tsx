"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function TotpSetupPage() {
  const router = useRouter();
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/2fa/setup")
      .then((r) => r.json())
      .then((data) => {
        setQrCode(data.qrCode);
        setSecret(data.secret);
      });
  }, []);

  async function onConfirm(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch("/api/2fa/setup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Code invalide.");
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <h1 className="font-display text-2xl text-parchment mb-2">
        Configuration obligatoire du 2FA
      </h1>
      <p className="text-sm text-mist mb-6">
        Ton compte a les permissions maximales (FONDA). Le 2FA est obligatoire avant
        d&apos;accéder au reste du dashboard.
      </p>

      {qrCode && (
        <div className="rounded-xl border border-white/10 bg-surface p-6 flex flex-col items-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={qrCode} alt="QR code 2FA" className="h-48 w-48 rounded-lg bg-white p-2" />
          <p className="text-xs text-mist mt-4 break-all text-center">
            Ou saisis ce code manuellement : <span className="text-goldSoft">{secret}</span>
          </p>
        </div>
      )}

      <form onSubmit={onConfirm} className="mt-6 space-y-4">
        <label className="block">
          <span className="block text-sm text-mist mb-1.5">Code généré par l&apos;application</span>
          <input
            required
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2.5 text-parchment outline-none focus:border-gold/60"
          />
        </label>
        {error && <p className="text-sm text-crimson">{error}</p>}
        <button className="w-full py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors">
          Activer le 2FA
        </button>
      </form>
    </div>
  );
}
