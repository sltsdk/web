"use client";

import { useEffect, useState } from "react";

type Review = {
  id: string;
  rating: number;
  comment: string;
  published: boolean;
  verified: boolean;
  user: { username: string };
  product: { name: string };
};

export default function ReviewsAdminPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  function load() {
    fetch("/api/admin/reviews")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setReviews(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  }

  useEffect(load, []);

  async function patch(id: string, body: Record<string, boolean>) {
    await fetch(`/api/admin/reviews/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    load();
  }

  async function remove(id: string) {
    if (!window.confirm("Supprimer cet avis ?")) return;
    await fetch(`/api/admin/reviews/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Avis</h1>
      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : reviews.length === 0 ? (
        <p className="text-mist">Aucun avis pour l&apos;instant.</p>
      ) : (
        <div className="space-y-3">
          {reviews.map((r) => (
            <div key={r.id} className="rounded-xl border border-white/10 bg-surface p-4">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <p className="text-parchment">
                    {r.product.name} · {"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}
                  </p>
                  <p className="text-sm text-mist mt-1">{r.comment}</p>
                  <p className="text-xs text-mist mt-1">par {r.user.username}</p>
                </div>
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => patch(r.id, { published: !r.published })}
                    className="px-3 py-1 text-xs rounded-full border border-white/10 hover:border-gold/40"
                  >
                    {r.published ? "Dépublier" : "Publier"}
                  </button>
                  <button
                    onClick={() => patch(r.id, { verified: !r.verified })}
                    className="px-3 py-1 text-xs rounded-full border border-white/10 hover:border-gold/40"
                  >
                    {r.verified ? "Retirer vérifié" : "Marquer vérifié"}
                  </button>
                  <button
                    onClick={() => remove(r.id)}
                    className="px-3 py-1 text-xs rounded-full border border-white/10 hover:border-crimson/50"
                  >
                    Supprimer
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
