"use client";

import { useEffect, useState } from "react";

type Order = {
  id: string;
  status: string;
  total: number;
  createdAt: string;
  user: { username: string; email: string };
  items: { quantity: number; product: { name: string } }[];
};

const STATUSES = ["PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELLED"];

export default function OrdersAdminPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  function load() {
    fetch("/api/admin/orders")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setOrders(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  }

  useEffect(load, []);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/admin/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Commandes</h1>
      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : orders.length === 0 ? (
        <p className="text-mist">Aucune commande pour l&apos;instant.</p>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="rounded-xl border border-white/10 bg-surface p-4">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <p className="text-parchment">{o.user.username} · {o.user.email}</p>
                  <p className="text-sm text-mist mt-1">
                    {o.items.map((i) => `${i.quantity}× ${i.product.name}`).join(", ")}
                  </p>
                  <p className="text-sm text-gold mt-1">{(o.total / 100).toFixed(2)} €</p>
                </div>
                <select
                  value={o.status}
                  onChange={(e) => updateStatus(o.id, e.target.value)}
                  className="rounded-lg border border-white/10 bg-ink px-3 py-1.5 text-sm text-parchment outline-none focus:border-gold/60"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
