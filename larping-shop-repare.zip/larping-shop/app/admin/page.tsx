import { prisma } from "@/lib/prisma";

export default async function AdminDashboard() {
  const [userCount, productCount, orderCount, openTickets] = await Promise.all([
    prisma.user.count(),
    prisma.product.count(),
    prisma.order.count(),
    prisma.ticket.count({ where: { status: "OPEN" } }),
  ]);

  const stats = [
    { label: "Utilisateurs", value: userCount },
    { label: "Produits", value: productCount },
    { label: "Commandes", value: orderCount },
    { label: "Tickets ouverts", value: openTickets },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Statistiques</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-white/10 bg-surface p-5">
            <p className="text-3xl font-display text-gold">{s.value}</p>
            <p className="text-sm text-mist mt-1">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
