"use client";

import { useEffect, useMemo, useState } from "react";

type Category = { id: string; name: string };
type Product = {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  stock: number;
  badge: string | null;
  categoryId: string | null;
  images: string;
};

type FormState = {
  name: string;
  slug: string;
  description: string;
  price: string;
  stock: string;
  categoryId: string;
  badge: string;
  imageUrl: string;
};

const EMPTY_FORM: FormState = {
  name: "",
  slug: "",
  description: "",
  price: "",
  stock: "",
  categoryId: "",
  badge: "",
  imageUrl: "",
};

function firstImage(images: string): string | null {
  try {
    const parsed = JSON.parse(images);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed[0] : null;
  } catch {
    return null;
  }
}

export default function ProductsAdminPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [editing, setEditing] = useState<Product | "new" | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");

  function load() {
    Promise.all([
      fetch("/api/admin/products").then((r) => (r.ok ? r.json() : [])),
      fetch("/api/admin/categories").then((r) => r.json()),
    ]).then(([p, c]) => {
      setProducts(Array.isArray(p) ? p : []);
      setCategories(Array.isArray(c) ? c : []);
      setLoading(false);
    });
  }

  useEffect(load, []);

  async function deleteProduct(id: string) {
    if (!window.confirm("Supprimer ce produit ?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    load();
  }

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = !categoryFilter || p.categoryId === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [products, search, categoryFilter]);

  return (
    <div>
      <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
        <h1 className="font-display text-2xl text-parchment">Produits</h1>
        <button
          onClick={() => setEditing("new")}
          className="px-4 py-2 rounded-full bg-gold text-ink text-sm font-medium hover:bg-goldSoft transition-colors"
        >
          + Ajouter un produit
        </button>
      </div>

      <div className="flex gap-3 mb-6 flex-wrap">
        <input
          placeholder="Rechercher un produit..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[200px] rounded-lg border border-white/10 bg-ink px-3 py-2 text-sm text-parchment outline-none focus:border-gold/60"
        />
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="rounded-lg border border-white/10 bg-ink px-3 py-2 text-sm text-parchment outline-none focus:border-gold/60"
        >
          <option value="">Toutes les catégories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {editing && (
        <ProductForm
          product={editing === "new" ? null : editing}
          categories={categories}
          onClose={() => setEditing(null)}
          onSaved={load}
        />
      )}

      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : filtered.length === 0 ? (
        <p className="text-mist">Aucun produit ne correspond.</p>
      ) : (
        <div className="space-y-2">
          {filtered.map((p) => {
            const img = firstImage(p.images);
            return (
              <div
                key={p.id}
                className="rounded-lg border border-white/10 bg-surface p-3 flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 shrink-0 rounded-md bg-surfaceHigh overflow-hidden grid place-items-center">
                    {img ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xs text-mist">—</span>
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="text-parchment truncate">{p.name}</p>
                    <p className="text-xs text-mist">
                      {(p.price / 100).toFixed(2)} € · stock {p.stock}
                      {p.badge ? ` · ${p.badge}` : ""}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button
                    onClick={() => setEditing(p)}
                    className="px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-gold/50 transition-colors"
                  >
                    Modifier
                  </button>
                  <button
                    onClick={() => deleteProduct(p.id)}
                    className="px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-crimson/50 transition-colors"
                  >
                    Supprimer
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ProductForm({
  product,
  categories,
  onClose,
  onSaved,
}: {
  product: Product | null;
  categories: Category[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = Boolean(product);
  const [form, setForm] = useState<FormState>(() => {
    if (!product) return EMPTY_FORM;
    return {
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: (product.price / 100).toString(),
      stock: product.stock.toString(),
      categoryId: product.categoryId ?? "",
      badge: product.badge ?? "",
      imageUrl: firstImage(product.images) ?? "",
    };
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Les deux routes stockent le même format en base (JSON stringifié),
    // mais /api/admin/products (création) attend un tableau JS qu'il
    // stringifie lui-même, tandis que /api/admin/products/[id] (édition)
    // attend directement la chaîne déjà stringifiée.
    const imageArray = form.imageUrl ? [form.imageUrl] : [];

    const body = isEdit
      ? {
          name: form.name,
          description: form.description,
          price: Math.round(Number(form.price) * 100),
          stock: Number(form.stock),
          categoryId: form.categoryId || null,
          badge: form.badge || null,
          images: JSON.stringify(imageArray),
        }
      : {
          name: form.name,
          slug: form.slug,
          description: form.description,
          price: Math.round(Number(form.price) * 100),
          stock: Number(form.stock),
          categoryId: form.categoryId || undefined,
          badge: form.badge || undefined,
          images: imageArray,
        };

    const res = await fetch(
      isEdit ? `/api/admin/products/${product!.id}` : "/api/admin/products",
      {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }
    );
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Erreur.");
      return;
    }
    onSaved();
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 px-4">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-surface p-6 max-h-[90vh] overflow-y-auto">
        <h2 className="font-display text-xl text-parchment mb-4">
          {isEdit ? "Modifier le produit" : "Nouveau produit"}
        </h2>
        <form onSubmit={onSubmit} className="space-y-3">
          <Input placeholder="Nom" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          {!isEdit && (
            <Input
              placeholder="Slug (url)"
              value={form.slug}
              onChange={(v) => setForm({ ...form, slug: v })}
            />
          )}
          <textarea
            required
            placeholder="Description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60 min-h-[80px]"
          />
          <Input
            placeholder="URL de l'image"
            value={form.imageUrl}
            onChange={(v) => setForm({ ...form, imageUrl: v })}
            required={false}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input placeholder="Prix (€)" type="number" value={form.price} onChange={(v) => setForm({ ...form, price: v })} />
            <Input placeholder="Stock" type="number" value={form.stock} onChange={(v) => setForm({ ...form, stock: v })} />
          </div>
          <select
            value={form.categoryId}
            onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          >
            <option value="">Sans catégorie</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <select
            value={form.badge}
            onChange={(e) => setForm({ ...form, badge: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          >
            <option value="">Aucun badge</option>
            <option value="Nouveau">Nouveau</option>
            <option value="Populaire">Populaire</option>
            <option value="Vérifié">Vérifié</option>
          </select>

          {error && <p className="text-sm text-crimson">{error}</p>}

          <div className="flex gap-2 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-2 rounded-full border border-white/10 text-parchment">
              Annuler
            </button>
            <button disabled={loading} className="flex-1 py-2 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors">
              {loading ? "Enregistrement..." : isEdit ? "Enregistrer" : "Créer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Input({
  placeholder,
  value,
  onChange,
  type = "text",
  required = true,
}: {
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <input
      required={required}
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
    />
  );
}
