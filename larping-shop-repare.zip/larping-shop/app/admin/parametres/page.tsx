"use client";

import { useEffect, useState } from "react";

type Settings = {
  shopName: string;
  bannerText: string | null;
  announcement: string | null;
  footerText: string | null;
  maintenanceMode: boolean;
};

export default function SettingsPage() {
  const [form, setForm] = useState<Settings | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/shop-settings")
      .then((r) => r.json())
      .then((data) => setForm(data));
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setSaved(false);
    const res = await fetch("/api/admin/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) setSaved(true);
  }

  if (!form) return <p className="text-mist">Chargement...</p>;

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-2">⚙️ Configuration du Shop</h1>
      <p className="text-sm text-mist mb-6">
        Réservé au FONDA. Ces réglages sont lus par le reste du site (nom, bannière, annonce, mode maintenance).
      </p>

      <form onSubmit={onSubmit} className="space-y-4 max-w-lg">
        <Field label="Nom du shop" value={form.shopName} onChange={(v) => setForm({ ...form, shopName: v })} />
        <Field
          label="Texte de bannière"
          value={form.bannerText ?? ""}
          onChange={(v) => setForm({ ...form, bannerText: v })}
        />
        <Field
          label="Annonce (bandeau en haut de la home)"
          value={form.announcement ?? ""}
          onChange={(v) => setForm({ ...form, announcement: v })}
        />
        <Field
          label="Texte de pied de page"
          value={form.footerText ?? ""}
          onChange={(v) => setForm({ ...form, footerText: v })}
        />
        <label className="flex items-center gap-2 text-sm text-parchment">
          <input
            type="checkbox"
            checked={form.maintenanceMode}
            onChange={(e) => setForm({ ...form, maintenanceMode: e.target.checked })}
          />
          Mode maintenance
        </label>

        {saved && <p className="text-sm text-gold">Paramètres enregistrés.</p>}

        <button className="px-5 py-2.5 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors">
          Enregistrer
        </button>
      </form>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <label className="block">
      <span className="block text-sm text-mist mb-1.5">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2.5 text-parchment outline-none focus:border-gold/60"
      />
    </label>
  );
}
