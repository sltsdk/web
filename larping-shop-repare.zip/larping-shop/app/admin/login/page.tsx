"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Shield } from "lucide-react";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [totpCode, setTotpCode] = useState("");
  const [needsTotp, setNeedsTotp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await signIn("credentials", {
      email,
      password,
      totpCode: needsTotp ? totpCode : undefined,
      redirect: false,
    });

    setLoading(false);

    if (res?.error === "TOTP_REQUIRED") {
      setNeedsTotp(true);
      return;
    }
    if (res?.error) {
      setError(res.error === "CredentialsSignin" ? "Identifiants invalides." : res.error);
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <div className="min-h-[80vh] grid place-items-center px-6">
      <div className="w-full max-w-sm rounded-2xl border border-gold/20 bg-surface p-8">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="h-5 w-5 text-gold" />
          <h1 className="font-display text-2xl text-parchment">Espace administration</h1>
        </div>
        <p className="text-sm text-mist mb-6">
          Réservé au staff (ADMIN / FONDA). Cette authentification est distincte du compte
          utilisateur classique.
        </p>

        <form onSubmit={onSubmit} className="space-y-4">
          {!needsTotp ? (
            <>
              <Field label="Email" type="email" value={email} onChange={setEmail} />
              <Field label="Mot de passe" type="password" value={password} onChange={setPassword} />
            </>
          ) : (
            <div>
              <p className="text-sm text-goldSoft mb-3">
                Entre le code à 6 chiffres de ton application d&apos;authentification.
              </p>
              <Field label="Code 2FA" type="text" value={totpCode} onChange={setTotpCode} />
            </div>
          )}
          {error && <p className="text-sm text-crimson">{error}</p>}
          <button
            disabled={loading}
            className="w-full py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors disabled:opacity-60"
          >
            {loading ? "Vérification..." : needsTotp ? "Valider le code" : "Continuer"}
          </button>
        </form>
      </div>
    </div>
  );
}

function Field({
  label,
  type,
  value,
  onChange,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="block text-sm text-mist mb-1.5">{label}</span>
      <input
        required
        autoFocus
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2.5 text-parchment outline-none focus:border-gold/60 transition-colors"
      />
    </label>
  );
}
