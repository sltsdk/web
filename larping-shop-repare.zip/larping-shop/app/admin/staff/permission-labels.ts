export const PERMISSION_LABELS = {
  products: "Produits",
  stocks: "Stocks",
  prices: "Prix",
  categories: "Catégories",
  reviews: "Avis",
  proofs: "Preuves",
  orders: "Commandes",
  users: "Utilisateurs",
  tickets: "Tickets",
  settings: "Paramètres",
} as const;
