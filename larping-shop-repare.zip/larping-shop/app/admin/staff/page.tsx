"use client";

import { useEffect, useState } from "react";
import { PERMISSION_LABELS } from "./permission-labels";

type StaffMember = {
  id: string;
  username: string;
  email: string;
  role: "ADMIN" | "FONDA";
  isActive: boolean;
  permission: Record<string, boolean> | null;
};

const PERMISSION_KEYS = Object.keys(PERMISSION_LABELS) as (keyof typeof PERMISSION_LABELS)[];

export default function StaffPage() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(true);

  function load() {
    fetch("/api/admin/staff")
      .then((r) => r.json())
      .then((data) => {
        setStaff(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  }

  useEffect(load, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl text-parchment">Gestion du Staff</h1>
        <button
          onClick={() => setShowCreate(true)}
          className="px-4 py-2 rounded-full bg-gold text-ink text-sm font-medium hover:bg-goldSoft transition-colors"
        >
          + Créer un administrateur
        </button>
      </div>

      {showCreate && <CreateAdminModal onClose={() => setShowCreate(false)} onCreated={load} />}

      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : (
        <div className="space-y-3">
          {staff.map((member) => (
            <StaffRow key={member.id} member={member} onChanged={load} />
          ))}
        </div>
      )}
    </div>
  );
}

function StaffRow({ member, onChanged }: { member: StaffMember; onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  const [permissions, setPermissions] = useState<Record<string, boolean>>(
    member.permission ?? Object.fromEntries(PERMISSION_KEYS.map((k) => [k, false]))
  );
  const [saving, setSaving] = useState(false);

  async function savePermissions() {
    setSaving(true);
    await fetch(`/api/admin/staff/${member.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ permissions }),
    });
    setSaving(false);
    onChanged();
  }

  async function toggleActive() {
    const confirmCritical = member.role === "FONDA" && member.isActive;
    if (confirmCritical) {
      const ok = window.confirm(
        `Action critique : désactiver le FONDA ${member.username}. Confirmer ?`
      );
      if (!ok) return;
    }
    const res = await fetch(`/api/admin/staff/${member.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !member.isActive, confirmCriticalAction: confirmCritical }),
    });
    if (res.status === 409) {
      window.alert("Confirmation supplémentaire requise ou action impossible.");
    }
    onChanged();
  }

  return (
    <div className="rounded-xl border border-white/10 bg-surface p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-parchment">
            {member.username}{" "}
            <span className="text-xs text-gold ml-2 uppercase">{member.role}</span>
            {!member.isActive && <span className="text-xs text-crimson ml-2">Désactivé</span>}
          </p>
          <p className="text-sm text-mist">{member.email}</p>
        </div>
        <div className="flex gap-2">
          {member.role === "ADMIN" && (
            <button
              onClick={() => setOpen((v) => !v)}
              className="px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-gold/40 transition-colors"
            >
              Permissions
            </button>
          )}
          <button
            onClick={toggleActive}
            className="px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-crimson/50 transition-colors"
          >
            {member.isActive ? "Désactiver" : "Réactiver"}
          </button>
        </div>
      </div>

      {open && (
        <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 gap-2">
          {PERMISSION_KEYS.map((key) => (
            <label key={key} className="flex items-center gap-2 text-sm text-parchment">
              <input
                type="checkbox"
                checked={Boolean(permissions[key])}
                onChange={(e) => setPermissions({ ...permissions, [key]: e.target.checked })}
              />
              {PERMISSION_LABELS[key]}
            </label>
          ))}
          <button
            onClick={savePermissions}
            disabled={saving}
            className="col-span-full mt-2 px-4 py-2 rounded-full bg-gold text-ink text-sm font-medium hover:bg-goldSoft transition-colors w-fit"
          >
            {saving ? "Enregistrement..." : "Enregistrer les permissions"}
          </button>
        </div>
      )}
    </div>
  );
}

function CreateAdminModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({ username: "", email: "", temporaryPassword: "" });
  const [permissions, setPermissions] = useState<Record<string, boolean>>(
    Object.fromEntries(PERMISSION_KEYS.map((k) => [k, false]))
  );
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/admin/staff", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, permissions }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Erreur.");
      return;
    }
    onCreated();
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 px-4">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-surface p-6">
        <h2 className="font-display text-xl text-parchment mb-4">Créer un administrateur</h2>
        <form onSubmit={onSubmit} className="space-y-3">
          <input
            required
            placeholder="Nom d'utilisateur"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          />
          <input
            required
            type="email"
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          />
          <input
            required
            type="text"
            placeholder="Mot de passe temporaire (10+ caractères)"
            value={form.temporaryPassword}
            onChange={(e) => setForm({ ...form, temporaryPassword: e.target.value })}
            className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          />

          <div className="grid grid-cols-2 gap-2 pt-2">
            {PERMISSION_KEYS.map((key) => (
              <label key={key} className="flex items-center gap-2 text-sm text-parchment">
                <input
                  type="checkbox"
                  checked={Boolean(permissions[key])}
                  onChange={(e) => setPermissions({ ...permissions, [key]: e.target.checked })}
                />
                {PERMISSION_LABELS[key]}
              </label>
            ))}
          </div>

          {error && <p className="text-sm text-crimson">{error}</p>}

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 rounded-full border border-white/10 text-parchment"
            >
              Annuler
            </button>
            <button
              disabled={loading}
              className="flex-1 py-2 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors"
            >
              {loading ? "Création..." : "Créer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
