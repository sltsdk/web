"use client";

import { useEffect, useState } from "react";

type User = { id: string; username: string; email: string; isActive: boolean; createdAt: string };

export default function UsersAdminPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  function load() {
    fetch("/api/admin/users")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setUsers(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  }

  useEffect(load, []);

  async function toggle(id: string, isActive: boolean) {
    await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Utilisateurs</h1>
      <p className="text-sm text-mist mb-4">
        Comptes clients standards uniquement. Les comptes ADMIN et FONDA se gèrent depuis{" "}
        <span className="text-goldSoft">Gestion du staff</span>.
      </p>
      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="rounded-lg border border-white/10 bg-surface p-3 flex items-center justify-between">
              <div>
                <p className="text-parchment">
                  {u.username} {!u.isActive && <span className="text-xs text-crimson ml-2">Banni</span>}
                </p>
                <p className="text-sm text-mist">{u.email}</p>
              </div>
              <button
                onClick={() => toggle(u.id, u.isActive)}
                className="px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-crimson/50 transition-colors"
              >
                {u.isActive ? "Bannir" : "Réactiver"}
              </button>
            </div>
          ))}
          {users.length === 0 && <p className="text-mist">Aucun utilisateur pour l&apos;instant.</p>}
        </div>
      )}
    </div>
  );
}
