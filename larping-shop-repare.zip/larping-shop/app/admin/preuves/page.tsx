"use client";

import { useEffect, useState } from "react";

type Proof = {
  id: string;
  type: string;
  content: string;
  product: { name: string };
  author: { username: string };
};
type Product = { id: string; name: string };

export default function ProofsAdminPage() {
  const [proofs, setProofs] = useState<Proof[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [form, setForm] = useState({ productId: "", type: "text", content: "" });
  const [loading, setLoading] = useState(true);

  function load() {
    Promise.all([
      fetch("/api/admin/proofs").then((r) => (r.ok ? r.json() : [])),
      fetch("/api/admin/products").then((r) => (r.ok ? r.json() : [])),
    ]).then(([pr, prod]) => {
      setProofs(Array.isArray(pr) ? pr : []);
      setProducts(Array.isArray(prod) ? prod : []);
      setLoading(false);
    });
  }

  useEffect(load, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.productId) return;
    await fetch("/api/admin/proofs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ productId: "", type: "text", content: "" });
    load();
  }

  async function remove(id: string) {
    if (!window.confirm("Supprimer cette preuve ?")) return;
    await fetch(`/api/admin/proofs/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Preuves</h1>

      <form onSubmit={onSubmit} className="rounded-xl border border-white/10 bg-surface p-4 mb-6 space-y-3">
        <select
          value={form.productId}
          onChange={(e) => setForm({ ...form, productId: e.target.value })}
          className="w-full rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
        >
          <option value="">Choisir un produit</option>
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <div className="flex gap-3">
          <select
            value={form.type}
            onChange={(e) => setForm({ ...form, type: e.target.value })}
            className="rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          >
            <option value="text">Texte</option>
            <option value="image">Image (URL)</option>
            <option value="document">Document (URL)</option>
          </select>
          <input
            required
            placeholder="Contenu (texte ou URL)"
            value={form.content}
            onChange={(e) => setForm({ ...form, content: e.target.value })}
            className="flex-1 rounded-lg border border-white/10 bg-ink px-3 py-2 text-parchment outline-none focus:border-gold/60"
          />
        </div>
        <button className="px-4 py-2 rounded-full bg-gold text-ink text-sm font-medium hover:bg-goldSoft transition-colors">
          Ajouter la preuve
        </button>
      </form>

      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : (
        <div className="space-y-2">
          {proofs.map((p) => (
            <div key={p.id} className="rounded-lg border border-white/10 bg-surface p-3 flex justify-between items-start gap-4">
              <div>
                <p className="text-parchment">{p.product.name} · <span className="text-xs text-mist">{p.type}</span></p>
                <p className="text-sm text-mist truncate max-w-md">{p.content}</p>
                <p className="text-xs text-mist mt-1">ajouté par {p.author.username}</p>
              </div>
              <button
                onClick={() => remove(p.id)}
                className="shrink-0 px-3 py-1.5 text-sm rounded-full border border-white/10 hover:border-crimson/50"
              >
                Supprimer
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
