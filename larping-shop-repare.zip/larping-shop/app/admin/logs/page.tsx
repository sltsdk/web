"use client";

import { useEffect, useState } from "react";

type AdminLog = { id: string; action: string; target: string | null; details: string | null; createdAt: string; actor: { username: string; role: string } };
type LoginLog = { id: string; email: string; success: boolean; ip: string | null; createdAt: string };

export default function LogsAdminPage() {
  const [adminLogs, setAdminLogs] = useState<AdminLog[]>([]);
  const [loginLogs, setLoginLogs] = useState<LoginLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/logs")
      .then((r) => (r.ok ? r.json() : { adminLogs: [], loginLogs: [] }))
      .then((data) => {
        setAdminLogs(data.adminLogs ?? []);
        setLoginLogs(data.loginLogs ?? []);
        setLoading(false);
      });
  }, []);

  if (loading) return <p className="text-mist">Chargement...</p>;

  return (
    <div className="space-y-10">
      <div>
        <h1 className="font-display text-2xl text-parchment mb-4">Journal des actions administrateur</h1>
        <div className="space-y-1.5">
          {adminLogs.map((l) => (
            <div key={l.id} className="text-sm rounded-lg border border-white/10 bg-surface px-3 py-2">
              <span className="text-goldSoft">{l.actor.username}</span>{" "}
              <span className="text-mist">({l.actor.role})</span> — {l.action}
              {l.target && <span className="text-mist"> sur {l.target}</span>}
              <span className="text-mist"> · {new Date(l.createdAt).toLocaleString("fr-FR")}</span>
            </div>
          ))}
          {adminLogs.length === 0 && <p className="text-mist">Aucune action enregistrée.</p>}
        </div>
      </div>

      <div>
        <h2 className="font-display text-xl text-parchment mb-4">Journal des connexions</h2>
        <div className="space-y-1.5">
          {loginLogs.map((l) => (
            <div key={l.id} className="text-sm rounded-lg border border-white/10 bg-surface px-3 py-2">
              <span className={l.success ? "text-gold" : "text-crimson"}>
                {l.success ? "✔ Succès" : "✘ Échec"}
              </span>{" "}
              — {l.email} {l.ip && <span className="text-mist">depuis {l.ip}</span>}
              <span className="text-mist"> · {new Date(l.createdAt).toLocaleString("fr-FR")}</span>
            </div>
          ))}
          {loginLogs.length === 0 && <p className="text-mist">Aucune connexion enregistrée.</p>}
        </div>
      </div>
    </div>
  );
}
