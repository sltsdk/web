"use client";

import { useEffect, useState } from "react";

type Ticket = {
  id: string;
  subject: string;
  message: string;
  status: string;
  user: { username: string; email: string };
};

const STATUSES = ["OPEN", "ANSWERED", "CLOSED"];

export default function TicketsAdminPage() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  function load() {
    fetch("/api/admin/tickets")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => {
        setTickets(Array.isArray(data) ? data : []);
        setLoading(false);
      });
  }

  useEffect(load, []);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/admin/tickets/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-parchment mb-6">Tickets de support</h1>
      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : tickets.length === 0 ? (
        <p className="text-mist">Aucun ticket pour l&apos;instant.</p>
      ) : (
        <div className="space-y-3">
          {tickets.map((t) => (
            <div key={t.id} className="rounded-xl border border-white/10 bg-surface p-4">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <p className="text-parchment">{t.subject}</p>
                  <p className="text-sm text-mist mt-1">{t.message}</p>
                  <p className="text-xs text-mist mt-1">
                    {t.user.username} · {t.user.email}
                  </p>
                </div>
                <select
                  value={t.status}
                  onChange={(e) => updateStatus(t.id, e.target.value)}
                  className="rounded-lg border border-white/10 bg-ink px-3 py-1.5 text-sm text-parchment outline-none focus:border-gold/60"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
