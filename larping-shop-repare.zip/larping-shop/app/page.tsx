import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function HomePage() {
  const settings = await prisma.shopSettings.findUnique({ where: { id: "singleton" } }).catch(() => null);
  const shopName = settings?.shopName ?? "Larping Shop";

  const products = await prisma.product
    .findMany({ take: 4, orderBy: { createdAt: "desc" } })
    .catch(() => []);

  return (
    <div>
      {settings?.announcement && (
        <div className="bg-crimson/90 text-parchment text-sm text-center py-2 px-4">
          {settings.announcement}
        </div>
      )}

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="font-display text-5xl sm:text-6xl leading-[1.05] text-parchment">
              L&apos;équipement qui donne vie à ton personnage.
            </h1>
            <p className="mt-6 text-lg text-mist max-w-md">
              Armes en mousse, armures, costumes et accessoires forgés pour le
              grandeur nature — choisis par des joueurs, pour des joueurs.
            </p>
            <div className="mt-8 flex gap-3">
              <Link
                href="/boutique"
                className="px-6 py-3 rounded-full bg-gold text-ink font-medium hover:bg-goldSoft transition-colors"
              >
                Explorer la boutique
              </Link>
              <Link
                href="/nouveautes"
                className="px-6 py-3 rounded-full border border-white/15 text-parchment hover:border-gold/50 transition-colors"
              >
                Voir les nouveautés
              </Link>
            </div>
          </div>
          <div className="relative aspect-square rounded-2xl border border-gold/20 bg-surface grid place-items-center">
            <span className="font-display text-2xl text-gold/70 italic">{shopName}</span>
          </div>
        </div>
      </section>

      {/* Produits récents */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex items-baseline justify-between mb-8">
          <h2 className="font-display text-2xl text-parchment">Récemment ajoutés</h2>
          <Link href="/nouveautes" className="text-sm text-gold hover:text-goldSoft">
            Tout voir
          </Link>
        </div>

        {products.length === 0 ? (
          <p className="text-mist">
            Aucun produit pour l&apos;instant — ajoute-en depuis le dashboard administrateur.
          </p>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
            {products.map((p) => (
              <div
                key={p.id}
                className="rounded-xl border border-white/10 bg-surface p-4 hover:border-gold/30 transition-colors"
              >
                <div className="aspect-square rounded-lg bg-surfaceHigh mb-3" />
                <p className="text-sm text-parchment">{p.name}</p>
                <p className="text-sm text-gold mt-1">{(p.price / 100).toFixed(2)} €</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
