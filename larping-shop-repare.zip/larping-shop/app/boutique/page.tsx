"use client";

import { useEffect, useState } from "react";
import { ProductCard, type PublicProduct } from "@/components/ProductCard";

type Category = { id: string; name: string };

export default function BoutiquePage() {
  const [products, setProducts] = useState<PublicProduct[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/categories")
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => setCategories(Array.isArray(data) ? data : []))
      .catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("q", search);
    if (categoryId) params.set("categoryId", categoryId);

    const timeout = setTimeout(() => {
      fetch(`/api/produits?${params.toString()}`)
        .then((r) => (r.ok ? r.json() : []))
        .then((data) => {
          setProducts(Array.isArray(data) ? data : []);
          setLoading(false);
        });
    }, 250); // léger debounce pour la recherche instantanée

    return () => clearTimeout(timeout);
  }, [search, categoryId]);

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <h1 className="font-display text-3xl text-parchment mb-8">La boutique</h1>

      <div className="flex gap-3 mb-8 flex-wrap">
        <input
          placeholder="Rechercher un produit..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 min-w-[220px] rounded-lg border border-white/10 bg-surface px-4 py-2.5 text-parchment outline-none focus:border-gold/60"
        />
        <select
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}
          className="rounded-lg border border-white/10 bg-surface px-4 py-2.5 text-parchment outline-none focus:border-gold/60"
        >
          <option value="">Toutes les catégories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <p className="text-mist">Chargement...</p>
      ) : products.length === 0 ? (
        <p className="text-mist">Aucun produit ne correspond à ta recherche.</p>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
