import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  password: z.string().min(8),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Champs invalides." }, { status: 400 });
  }
  const { username, email, password } = parsed.data;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email: email.toLowerCase() }, { username }] },
  });
  if (existing) {
    return NextResponse.json({ error: "Email ou nom d'utilisateur déjà utilisé." }, { status: 409 });
  }

  // Coût bcrypt volontairement élevé : le hash n'est jamais stocké en clair.
  const passwordHash = await bcrypt.hash(password, 12);

  // IMPORTANT : le rôle est TOUJOURS forcé à USER ici. Il n'y a aucun moyen,
  // via cette route publique, de créer un compte ADMIN ou FONDA.
  const user = await prisma.user.create({
    data: { username, email: email.toLowerCase(), passwordHash, role: "USER" },
  });

  return NextResponse.json({ id: user.id, username: user.username });
}
