import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateTotpSecret, totpQrCodeDataUrl, verifyTotpCode } from "@/lib/totp";

// Étape 1 : générer un secret + QR code à scanner (Google Authenticator, etc.)
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const secret = generateTotpSecret();
  const settings = await prisma.shopSettings.findUnique({ where: { id: "singleton" } });

  // Stocké temporairement (non activé) le temps que l'utilisateur confirme un code.
  await prisma.user.update({
    where: { id: session.user.id },
    data: { totpSecret: secret, totpEnabled: false },
  });

  const qrCode = await totpQrCodeDataUrl(
    session.user.email ?? session.user.id,
    secret,
    settings?.shopName ?? "Larping Shop"
  );

  return NextResponse.json({ secret, qrCode });
}

// Étape 2 : confirmer avec un code généré par l'app d'authentification
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  const { code } = await req.json().catch(() => ({ code: "" }));
  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user?.totpSecret) {
    return NextResponse.json({ error: "Aucune configuration 2FA en cours." }, { status: 400 });
  }

  const valid = verifyTotpCode(user.totpSecret, code);
  if (!valid) return NextResponse.json({ error: "Code invalide." }, { status: 400 });

  await prisma.user.update({ where: { id: user.id }, data: { totpEnabled: true } });
  return NextResponse.json({ ok: true });
}
