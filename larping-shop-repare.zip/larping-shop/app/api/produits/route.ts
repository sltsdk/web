import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Route publique (pas d'auth requise) : recherche + filtre catégorie sur le
// catalogue. Volontairement en lecture seule, aucune donnée sensible exposée.
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim() ?? "";
  const categoryId = searchParams.get("categoryId")?.trim() ?? "";

  const products = await prisma.product.findMany({
    where: {
      ...(q ? { name: { contains: q } } : {}),
      ...(categoryId ? { categoryId } : {}),
    },
    include: { category: { select: { name: true, slug: true } } },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(products);
}
