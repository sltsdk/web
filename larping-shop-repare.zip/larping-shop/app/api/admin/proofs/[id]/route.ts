import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("proofs");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  await prisma.proof.delete({ where: { id: params.id } });
  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "DELETE_PROOF", target: params.id },
  });
  return NextResponse.json({ ok: true });
}
