import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireStaff("proofs");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const proofs = await prisma.proof.findMany({
    include: { product: { select: { name: true } }, author: { select: { username: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(proofs);
}

const schema = z.object({
  productId: z.string(),
  type: z.enum(["text", "image", "document"]),
  content: z.string().min(1),
});

export async function POST(req: Request) {
  const session = await requireStaff("proofs");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  const proof = await prisma.proof.create({ data: { ...parsed.data, authorId: session.user.id } });

  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "CREATE_PROOF", target: proof.id },
  });

  return NextResponse.json(proof);
}
