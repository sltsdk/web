import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { PERMISSION_KEYS } from "@/lib/permissions";

async function requireFonda() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "FONDA") return null;
  return session;
}

export async function GET() {
  const session = await requireFonda();
  if (!session) return NextResponse.json({ error: "Non autorisé." }, { status: 403 });

  const staff = await prisma.user.findMany({
    where: { role: { in: ["ADMIN", "FONDA"] } },
    include: { permission: true },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json(staff.map((u) => ({ ...u, passwordHash: undefined })));
}

const createSchema = z.object({
  username: z.string().min(3).max(32),
  email: z.string().email(),
  temporaryPassword: z.string().min(10),
  permissions: z.record(z.boolean()).optional(),
});

export async function POST(req: Request) {
  const session = await requireFonda();
  if (!session) return NextResponse.json({ error: "Non autorisé." }, { status: 403 });

  const parsed = createSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });
  const { username, email, temporaryPassword, permissions } = parsed.data;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email: email.toLowerCase() }, { username }] },
  });
  if (existing) {
    return NextResponse.json({ error: "Email ou nom d'utilisateur déjà utilisé." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(temporaryPassword, 12);
  const permissionData = Object.fromEntries(
    PERMISSION_KEYS.map((k) => [k, Boolean(permissions?.[k])])
  );

  const admin = await prisma.user.create({
    data: {
      username,
      email: email.toLowerCase(),
      passwordHash,
      role: "ADMIN",
      permission: { create: permissionData },
    },
  });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "CREATE_ADMIN",
      target: admin.id,
      details: `Création de l'administrateur ${admin.username}`,
    },
  });

  // L'admin devra changer ce mot de passe temporaire à sa première connexion
  // (à brancher sur un flag forcePasswordChange si besoin).
  return NextResponse.json({ id: admin.id, username: admin.username });
}
