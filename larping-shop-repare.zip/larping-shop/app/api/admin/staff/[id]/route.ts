import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { PERMISSION_KEYS, canModifyFonda } from "@/lib/permissions";

const patchSchema = z.object({
  isActive: z.boolean().optional(),
  role: z.enum(["ADMIN", "FONDA"]).optional(),
  permissions: z.record(z.boolean()).optional(),
  // Pour les actions les plus sensibles (rétrograder/désactiver un FONDA),
  // on exige une confirmation explicite envoyée par le frontend.
  confirmCriticalAction: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "FONDA") {
    return NextResponse.json({ error: "Non autorisé." }, { status: 403 });
  }

  const parsed = patchSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });
  const { isActive, role, permissions, confirmCriticalAction } = parsed.data;

  const target = await prisma.user.findUnique({ where: { id: params.id } });
  if (!target) return NextResponse.json({ error: "Introuvable." }, { status: 404 });

  // Actions critiques : désactiver/rétrograder un FONDA existant
  if (target.role === "FONDA" && (isActive === false || role === "ADMIN")) {
    if (!confirmCriticalAction) {
      return NextResponse.json(
        { error: "CONFIRMATION_REQUISE", message: "Confirmation supplémentaire requise pour cette action critique." },
        { status: 409 }
      );
    }
    const check = await canModifyFonda(session.user.id, target.id);
    if (!check.ok) return NextResponse.json({ error: check.reason }, { status: 400 });
  }

  const updated = await prisma.user.update({
    where: { id: target.id },
    data: {
      ...(isActive !== undefined ? { isActive } : {}),
      ...(role ? { role } : {}),
    },
  });

  if (permissions) {
    const permissionData = Object.fromEntries(
      PERMISSION_KEYS.map((k) => [k, Boolean(permissions[k])])
    );
    await prisma.permission.upsert({
      where: { userId: target.id },
      create: { userId: target.id, ...permissionData },
      update: permissionData,
    });
  }

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "UPDATE_STAFF",
      target: target.id,
      details: JSON.stringify({ isActive, role, permissions }),
    },
  });

  return NextResponse.json({ id: updated.id, ok: true });
}
