import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

const schema = z.object({ published: z.boolean().optional(), verified: z.boolean().optional() });

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("reviews");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  const review = await prisma.review.update({ where: { id: params.id }, data: parsed.data });

  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "MODERATE_REVIEW", target: review.id, details: JSON.stringify(parsed.data) },
  });

  return NextResponse.json(review);
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("reviews");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  await prisma.review.delete({ where: { id: params.id } });
  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "DELETE_REVIEW", target: params.id },
  });
  return NextResponse.json({ ok: true });
}
