import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireStaff("reviews");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const reviews = await prisma.review.findMany({
    include: { user: { select: { username: true } }, product: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(reviews);
}
