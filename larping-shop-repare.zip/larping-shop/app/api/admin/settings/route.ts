import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireFondaSession } from "@/lib/adminGuard";

const schema = z.object({
  shopName: z.string().min(2).optional(),
  logoUrl: z.string().url().nullable().optional(),
  faviconUrl: z.string().url().nullable().optional(),
  primaryColor: z.string().optional(),
  bannerText: z.string().nullable().optional(),
  announcement: z.string().nullable().optional(),
  footerText: z.string().nullable().optional(),
  maintenanceMode: z.boolean().optional(),
});

export async function PATCH(req: Request) {
  // Réservé au FONDA : la config globale du shop n'est pas une permission
  // déléguable à un ADMIN dans cette version (cf. cahier des charges).
  const session = await requireFondaSession();
  if (!session) return NextResponse.json({ error: "Réservé au FONDA." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  const settings = await prisma.shopSettings.upsert({
    where: { id: "singleton" },
    create: { id: "singleton", ...parsed.data },
    update: parsed.data,
  });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "UPDATE_SHOP_SETTINGS",
      details: JSON.stringify(parsed.data),
    },
  });

  return NextResponse.json(settings);
}
