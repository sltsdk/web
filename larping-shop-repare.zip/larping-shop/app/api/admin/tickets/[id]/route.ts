import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

const schema = z.object({ status: z.enum(["OPEN", "ANSWERED", "CLOSED"]) });

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("tickets");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Statut invalide." }, { status: 400 });

  const ticket = await prisma.ticket.update({ where: { id: params.id }, data: { status: parsed.data.status } });

  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "UPDATE_TICKET", target: ticket.id, details: parsed.data.status },
  });

  return NextResponse.json(ticket);
}
