import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireStaff("tickets");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const tickets = await prisma.ticket.findMany({
    include: { user: { select: { username: true, email: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(tickets);
}
