import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const categories = await prisma.category.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json(categories);
}

const schema = z.object({ name: z.string().min(2), slug: z.string().min(2) });

export async function POST(req: Request) {
  const session = await requireStaff("categories");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  const category = await prisma.category.create({ data: parsed.data });
  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "CREATE_CATEGORY", target: category.id },
  });
  return NextResponse.json(category);
}
