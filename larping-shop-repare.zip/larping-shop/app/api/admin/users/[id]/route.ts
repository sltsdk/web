import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

const schema = z.object({ isActive: z.boolean() });

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("users");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  // Cette route ne touche qu'aux comptes USER — jamais à un ADMIN/FONDA
  // (leur gestion passe exclusivement par /api/admin/staff, réservé au FONDA).
  const target = await prisma.user.findUnique({ where: { id: params.id } });
  if (!target || target.role !== "USER") {
    return NextResponse.json({ error: "Cible invalide." }, { status: 400 });
  }

  const user = await prisma.user.update({ where: { id: params.id }, data: { isActive: parsed.data.isActive } });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: parsed.data.isActive ? "REACTIVATE_USER" : "BAN_USER",
      target: user.id,
    },
  });

  return NextResponse.json({ id: user.id, isActive: user.isActive });
}
