import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireStaff("users");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const users = await prisma.user.findMany({
    where: { role: "USER" },
    select: { id: true, username: true, email: true, isActive: true, createdAt: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(users);
}
