import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireStaff("orders");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const orders = await prisma.order.findMany({
    include: { user: { select: { username: true, email: true } }, items: { include: { product: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(orders);
}
