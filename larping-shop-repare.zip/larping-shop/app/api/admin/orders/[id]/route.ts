import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

const schema = z.object({ status: z.enum(["PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELLED"]) });

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("orders");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Statut invalide." }, { status: 400 });

  const order = await prisma.order.update({ where: { id: params.id }, data: { status: parsed.data.status } });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "UPDATE_ORDER_STATUS",
      target: order.id,
      details: parsed.data.status,
    },
  });

  return NextResponse.json(order);
}
