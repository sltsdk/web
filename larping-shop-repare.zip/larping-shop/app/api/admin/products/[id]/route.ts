import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireStaff } from "@/lib/adminGuard";

const patchSchema = z.object({
  name: z.string().min(2).optional(),
  description: z.string().min(1).optional(),
  price: z.number().int().nonnegative().optional(),
  stock: z.number().int().nonnegative().optional(),
  categoryId: z.string().nullable().optional(),
  badge: z.enum(["Nouveau", "Populaire", "Vérifié"]).nullable().optional(),
  images: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("products");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = patchSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });

  const product = await prisma.product.update({ where: { id: params.id }, data: parsed.data });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "UPDATE_PRODUCT",
      target: product.id,
      details: JSON.stringify(parsed.data),
    },
  });

  return NextResponse.json(product);
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const session = await requireStaff("products");
  if (!session) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  await prisma.product.delete({ where: { id: params.id } });

  await prisma.adminLog.create({
    data: { actorId: session.user.id, action: "DELETE_PRODUCT", target: params.id },
  });

  return NextResponse.json({ ok: true });
}
