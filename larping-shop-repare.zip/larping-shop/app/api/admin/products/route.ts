import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { hasPermission } from "@/lib/permissions";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });
  const allowed = await hasPermission(session.user.id, "products");
  if (!allowed) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const products = await prisma.product.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json(products);
}

const productSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2),
  description: z.string().min(1),
  price: z.number().int().nonnegative(),
  stock: z.number().int().nonnegative(),
  categoryId: z.string().optional(),
  images: z.array(z.string()).optional(),
  tags: z.array(z.string()).optional(),
  badge: z.enum(["Nouveau", "Populaire", "Vérifié"]).optional(),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Non authentifié." }, { status: 401 });

  // Vérification SERVEUR de la permission — jamais uniquement côté UI.
  const allowed = await hasPermission(session.user.id, "products");
  if (!allowed) return NextResponse.json({ error: "Permission refusée." }, { status: 403 });

  const parsed = productSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Champs invalides." }, { status: 400 });
  const data = parsed.data;

  const product = await prisma.product.create({
    data: {
      name: data.name,
      slug: data.slug,
      description: data.description,
      price: data.price,
      stock: data.stock,
      categoryId: data.categoryId,
      images: JSON.stringify(data.images ?? []),
      tags: JSON.stringify(data.tags ?? []),
      badge: data.badge,
    },
  });

  await prisma.adminLog.create({
    data: {
      actorId: session.user.id,
      action: "CREATE_PRODUCT",
      target: product.id,
      details: `Création du produit ${product.name}`,
    },
  });

  return NextResponse.json(product);
}
