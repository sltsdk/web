import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireFondaSession } from "@/lib/adminGuard";

export async function GET() {
  const session = await requireFondaSession();
  if (!session) return NextResponse.json({ error: "Réservé au FONDA." }, { status: 403 });

  const [adminLogs, loginLogs] = await Promise.all([
    prisma.adminLog.findMany({
      include: { actor: { select: { username: true, role: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    prisma.loginLog.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
  ]);

  return NextResponse.json({ adminLogs, loginLogs });
}
