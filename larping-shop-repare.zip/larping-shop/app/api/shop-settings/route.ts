import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Lecture publique de la configuration du shop (nom, bannière, annonce...).
// Écriture réservée au FONDA via /api/admin/settings.
export async function GET() {
  const settings = await prisma.shopSettings.upsert({
    where: { id: "singleton" },
    create: { id: "singleton" },
    update: {},
  });
  return NextResponse.json(settings);
}
