import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const { FONDA_USERNAME, FONDA_EMAIL, FONDA_PASSWORD } = process.env;

  if (!FONDA_USERNAME || !FONDA_EMAIL || !FONDA_PASSWORD) {
    console.error(
      "❌ FONDA_USERNAME, FONDA_EMAIL et FONDA_PASSWORD doivent être définis dans .env avant de lancer le seed."
    );
    process.exit(1);
  }

  const existingFonda = await prisma.user.findFirst({ where: { role: "FONDA" } });
  if (existingFonda) {
    console.log("ℹ️ Un compte FONDA existe déjà :", existingFonda.email);
    return;
  }

  const passwordHash = await bcrypt.hash(FONDA_PASSWORD, 12);

  const fonda = await prisma.user.create({
    data: {
      username: FONDA_USERNAME,
      email: FONDA_EMAIL.toLowerCase(),
      passwordHash,
      role: "FONDA",
    },
  });

  await prisma.shopSettings.upsert({
    where: { id: "singleton" },
    create: { id: "singleton" },
    update: {},
  });

  console.log("✅ Compte FONDA créé :", fonda.email);
  console.log(
    "⚠️ Le 2FA est OBLIGATOIRE pour FONDA : connecte-toi une première fois sur /admin/login, tu seras redirigé pour configurer ton application d'authentification avant de pouvoir accéder au dashboard."
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
